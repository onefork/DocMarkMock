# DocMark — 文档转换工具 SPA 全套界面设计方案

## 概述

为「图片/PDF 扫描件转 Markdown」的 SaaS 产品设计完整的**功能界面**（非营销落地页），面向普通文员和管理人员。视觉风格为**简洁专业**（Notion/Google 风格），同时适配手机和 PC 端。

**产品名称**：DocMark（暂定）
**核心价值**：一键上传 → 智能转换 → 编辑校对 → 导出分享

---

## 当前状态分析

- 用户工作目录 `/workspace` 中无现有 `.design` 项目
- 无已选 Design Library，走 Free Explore 模式
- 用户需求清晰：全套功能界面 + 简洁专业风格 + 响应式（手机+PC）
- 属于多设备项目（mobile + desktop 两种视图），需创建两个 `.design` 项目

---

## 页面清单与设备分配

### PC 端项目（deviceType: 'desktop'）— 5 个页面

| # | 页面 | slug | 页面类型 | 说明 |
|---|------|------|----------|------|
| 1 | 登录/注册 | `auth` | task-driven | 居中表单卡片，Tab 切换登录/注册，支持社交登录 |
| 2 | 文件管理仪表盘 | `dashboard` | information-dense | 左侧边栏 + 右侧文件列表/卡片，含 KPI 概览 |
| 3 | 文件上传页 | `upload` | task-driven | 大面积拖放区 + 批量文件队列 + 进度反馈 |
| 4 | 转换结果/编辑器 | `editor` | information-dense | 左右分屏：左侧 Markdown 编辑器 + 右侧实时预览/原文对照 |
| 5 | 导出设置 | `export` | task-driven | 格式选择 + 导出目标 + 下载按钮 |

### 移动端项目（deviceType: 'mobile'）— 5 个页面

| # | 页面 | slug | 页面类型 | 说明 |
|---|------|------|----------|------|
| 1 | 登录/注册 | `auth` | task-driven | 单列居中，大触摸目标 |
| 2 | 文件管理列表 | `dashboard` | information-dense | 底部 Tab 导航 + 文件卡片列表，无侧边栏 |
| 3 | 文件上传页 | `upload` | task-driven | 全宽拖放区 + 文件队列列表 |
| 4 | 编辑器 | `editor` | information-dense | Tab 切换「编辑/预览」，全宽单面板 |
| 5 | 导出设置 | `export` | task-driven | 底部弹出式导出面板 |

---

## 视觉风格定义

### 色彩体系 — Notion 温暖中性风

```
核心中性色:
  --bg-primary:        #FFFFFF       纯白背景
  --bg-secondary:      #F7F6F3       暖米白（侧边栏/hover）
  --bg-hover:          #F1F1EF       悬停背景
  --border-default:    #E9E9E7       暖灰边框
  --text-primary:      #37352F       暖棕黑主文字
  --text-secondary:    #787774       次要文字
  --text-placeholder:  #C3C2BF       占位符

强调色:
  --color-primary:     #2383E2       品牌蓝（按钮/链接/高亮）
  --color-primary-hover:#1A6FCA       蓝色悬停

语义色:
  --state-success:     #0F7B6C       成功绿
  --state-warning:     #D9730D       警告橙
  --state-error:       #E03E3E       错误红
  --state-info:        #2383E2       信息蓝
```

### 圆角

```
  --radius-sm:   4px
  --radius-md:   8px
  --radius-lg:   12px
  --radius-full: 9999px
```

### 字体

```
  标题:  Inter / Noto Sans SC, sans-serif
  正文:  Inter / Noto Sans SC, sans-serif
  代码:  JetBrains Mono, monospace

  字号层级:
    H1: 28px / Semibold
    H2: 22px / Semibold
    H3: 18px / Semibold
    Body: 15px / Regular
    Caption: 13px / Regular
    Small: 12px / Regular
```

### 阴影策略

- 静态卡片/表格/面板：使用边框（border），不使用阴影
- 浮动层（弹窗/下拉/抽屉/toast）：允许阴影，alpha <= 0.08

---

## 各页面详细设计说明

### 页面 1: 登录/注册（PC + Mobile）

**PC 端布局**：
- 单列居中卡片（宽度 420px），大量留白
- 顶部：Logo + 产品名「DocMark」
- Tab 切换：登录 / 注册
- 表单字段：邮箱、密码、（注册时）确认密码
- 社交登录：Google / Microsoft 按钮
- 底部：隐私政策链接

**Mobile 适配**：
- 卡片全宽（两侧 padding 24px）
- 触摸目标最小 44px
- 底部安全区域 padding

### 页面 2: 文件管理仪表盘（PC + Mobile）

**PC 端布局**：
- 左侧边栏（240px，可折叠至 64px 图标模式）
  - Logo
  - 导航项：全部文件、最近转换、收藏、模板库、回收站
  - 底部：用户头像 + 设置
- 右侧主内容区：
  - 顶部搜索栏 + 新建转换按钮
  - KPI 指标条（3 格）：总文件数 / 本月转换 / 存储用量
  - 文件列表区：支持表格视图 + 卡片视图切换
  - 表格列：文件名 + 缩略图 | 类型 | 大小 | 转换状态 | 修改时间 | 操作（编辑/下载/删除）

**Mobile 适配**：
- 无侧边栏，改为底部 Tab 栏（5 个入口）
- KPI 指标条改为横向滚动
- 表格视图改为堆叠卡片列表
- 搜索栏固定在顶部

### 页面 3: 文件上传页（PC + Mobile）

**PC 端布局**：
- 页面中心大面积拖放区（宽度 60%，虚线边框）
- 拖放区内容：上传图标 + 文字「拖拽文件到此处，或点击选择」+ 格式提示
- 拖放区下方：已选文件列表（卡片形式）
  - 每卡片：文件类型图标 + 文件名 + 大小 + 删除按钮
  - 底部：「继续添加」按钮
- 右侧或下方：开始转换按钮（大面积）

**Mobile 适配**：
- 拖放区全宽，按钮放大至 44px 触摸目标
- 文件列表改为纵向堆叠

### 页面 4: 转换结果/编辑器（PC + Mobile）

**PC 端布局 — 左右分屏**：
- 顶部工具栏：返回按钮、文件名（可编辑）、格式化按钮组、导出下拉菜单
- 左侧面板（50%）：Markdown 文本编辑区，等宽字体，行号
- 右侧面板（50%）：实时渲染预览 / 原文对照预览（Tab 切换）
- 可拖拽分割线
- 底部状态栏：字数统计、保存状态

**Mobile 适配**：
- 工具栏简化（仅核心按钮）
- 编辑器/预览通过 Tab 切换，各自全宽
- 工具栏浮动底部

### 页面 5: 导出设置（PC + Mobile）

**PC 端布局**：
- 居中面板（宽度 560px）
- 文件预览缩略图 + 文件名
- 导出格式选择：Markdown / HTML / 纯文本 / PDF（卡片式单选）
- 导出目标：直接下载 / 复制到剪贴板
- 底部：取消 + 确认导出按钮

**Mobile 适配**：
- 格式选择改为底部 Sheet（Bottom Sheet）
- 全宽布局

---

## 实施步骤

### Step 1: 风格确认

- 由于用户已明确选择「简洁专业」风格，跳过风格询问
- 直接基于 Notion 温暖中性风格生成 `colors_and_type.css`
- PC 和 Mobile 项目共享同一份品牌 CSS

### Step 2: PC 端项目初始化

- 创建目录结构：`docmark-pc/`、`docmark-pc/pages/`、`docmark-pc/assets/`
- 生成 `colors_and_type.css`（共享品牌 CSS）
- 创建 `.design` 文件，预写 5 个页面骨架节点（auth、dashboard、upload、editor、export）

### Step 3: Mobile 端项目初始化

- 创建目录结构：`docmark-mobile/`、`docmark-mobile/pages/`、`docmark-mobile/assets/`
- 复制共享品牌 CSS
- 创建 `.design` 文件，预写 5 个页面骨架节点

### Step 4: 图片资源预生成

- 为各页面生成需要的 Hero/插图类图片资产（每个页面 1-2 张关键图片）
- 所有图片注册到对应 `.design` 文件的 image 节点

### Step 5: PC 端页面生成（并行）

- 并行 dispatch 5 个 Sub-Agent 生成 PC 端 HTML 页面
- 每个 Sub-Agent 读取约束文件后独立生成

### Step 6: Mobile 端页面生成（并行）

- 并行 dispatch 5 个 Sub-Agent 生成 Mobile 端 HTML 页面

### Step 7: 页面排序与导航配置

- 调整两个项目的页面顺序
- 注册 visible wiring：auth → dashboard → upload → editor → export
- 配置全局导航和返回按钮的 hidden interactions

### Step 8: 验证与预览

- 对两个项目分别执行 `scan-design-directory.mjs` 验证
- 确认所有页面和图片节点正确注册
- 呈现最终结果

---

## 假设与决策

1. **产品名称**：暂定「DocMark」，用户可在后续迭代中修改
2. **不需要营销落地页**：用户明确选择仅功能界面
3. **响应式策略**：PC 端和 Mobile 端分别创建独立 `.design` 项目，共享品牌 CSS 保证视觉一致性
4. **无暗色模式**：首次设计仅做浅色主题，后续可迭代
5. **交互状态**：如上传进度、空状态、loading 等状态嵌入各页面 HTML 内通过视觉展示，不做独立状态页

---

## 验证方式

- 对 `docmark-pc/` 和 `docmark-mobile/` 分别运行验证脚本
- 确认 `.design` 文件中所有页面和图片节点完整
- 确认所有 HTML 文件引用正确的 `colors_and_type.css`
- 在 canvas 中打开两个项目，确认页面渲染和导航正确
